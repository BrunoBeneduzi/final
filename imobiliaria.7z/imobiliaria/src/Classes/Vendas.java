/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author bbernard
 */
public class Vendas{
     private String nome, bairro, rua, numero, nomeComprador;
     private int cod_vendedor, cod_casa, valor , cod_casas, cod_vendedo;

    public Vendas(){
    }
    
    
     public Vendas(int cod_vendedo, int cod_casas,String nomeComprador, int valor){
       
        this.cod_casas = cod_casa;
        this.cod_vendedo = cod_vendedor;
        this.nomeComprador = nomeComprador;
        this.valor = valor;
    }
    
    public Vendas(int cod_vendedor, int cod_vendedo ,int cod_casa, String nome, String bairro, String rua, String numero, String nomeComprador, int valor){
        this.bairro = bairro;
        this.cod_casa = cod_casa;
        this.cod_vendedor = cod_vendedor;
        this.nome = nome;
        this.nomeComprador = nomeComprador;
        this.numero = numero;
        this.rua = rua;
        this.valor = valor;
        this.cod_vendedo = cod_vendedo;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the bairro
     */
    public String getBairro() {
        return bairro;
    }

    /**
     * @param bairro the bairro to set
     */
    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    /**
     * @return the rua
     */
    public String getRua() {
        return rua;
    }

    /**
     * @param rua the rua to set
     */
    public void setRua(String rua) {
        this.rua = rua;
    }

    /**
     * @return the numero
     */
    public String getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(String numero) {
        this.numero = numero;
    }

    /**
     * @return the nomeComprador
     */
    public String getNomeComprador() {
        return nomeComprador;
    }

    /**
     * @param nomeComprador the nomeComprador to set
     */
    public void setNomeComprador(String nomeComprador) {
        this.nomeComprador = nomeComprador;
    }

    /**
     * @return the cod_vendedor
     */
    public int getCod_vendedor() {
        return cod_vendedor;
    }

    /**
     * @param cod_vendedor the cod_vendedor to set
     */
    public void setCod_vendedor(int cod_vendedor) {
        this.cod_vendedor = cod_vendedor;
    }

    /**
     * @return the cod_casa
     */
    public int getCod_casa() {
        return cod_casa;
    }

    /**
     * @param cod_casa the cod_casa to set
     */
    public void setCod_casa(int cod_casa) {
        this.cod_casa = cod_casa;
    }

    /**
     * @return the valor
     */
    public int getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(int valor) {
        this.valor = valor;
    }

    /**
     * @return the cod_casas
     */
    public int getCod_casas() {
        return cod_casas;
    }

    /**
     * @param cod_casas the cod_casas to set
     */
    public void setCod_casas(int cod_casas) {
        this.cod_casas = cod_casas;
    }

    /**
     * @return the cod_vendedo
     */
    public int getCod_vendedo() {
        return cod_vendedo;
    }

    /**
     * @param cod_vendedo the cod_vendedo to set
     */
    public void setCod_vendedo(int cod_vendedo) {
        this.cod_vendedo = cod_vendedo;
    }
    
    
   
    
      
}