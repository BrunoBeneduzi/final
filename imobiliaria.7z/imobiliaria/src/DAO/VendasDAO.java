/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Classes.Casa;
import Classes.Vendas;
import Classes.Vendedores;
import Conexao.ConexaoAulaDAO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;

/**
 *
 * @author bbernard
 */
public class VendasDAO {
      private Connection conn;

    public VendasDAO() {
        try {
            this.conn = ConexaoAulaDAO.getConnection();
        } catch (Exception e) {
            System.out.println("Erro de conexão: " + ":\n" + e.getMessage());
        }
    }

    public ArrayList listar() {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList vendas = new ArrayList();
        //ChatGPT be like:
        try {
            String SQL = "SELECT vendedor.cod_vendedor, vendas.cod_vendedo ,casas.cod_casa, vendedor.nome, casas.bairro, casas.rua, casas.numero, vendas.nomeComprador, vendas.valor FROM vendedor, casas, vendas WHERE vendedor.cod_vendedor = vendas.cod_vendedo AND casas.cod_casa = vendas.cod_casa;";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            
            rs = ps.executeQuery();

            while (rs.next()) {
                int cod_vendedor = rs.getInt("cod_vendedor");
                int cod_vendedo = rs.getInt("cod_vendedo");
                int cod_casa = rs.getInt("cod_casa");
                String nome = rs.getString("nome");
                String bairro = rs.getString("bairro");
                String rua = rs.getString("rua");
                String numero = rs.getString("numero");
                String nomeComprador = rs.getString("nomeComprador");
                int valor = rs.getInt("valor");
            

               
                vendas.add(new Vendas(cod_vendedor,cod_vendedo ,cod_casa, nome, bairro, rua, numero, nomeComprador, valor));
            }

        } catch (SQLException sqle) {
            System.out.println("Erro ao listar Consultas " + sqle);
        } finally {
            ConexaoAulaDAO.close(connL, ps, rs);
        }
        return vendas;
    }
    
    
    
    public void Inserir(Vendas pessoa) throws ErpDAOException {         
        PreparedStatement ps = null;
        Connection connL = null;        
        if (pessoa == null){
             throw new ErpDAOException("o objeto não pode ser nulo");
        }
        try{
            String SQL = "INSERT INTO vendas (cod_vendedo, cod_casa, nomeComprador, valor) " +
                    "values (?,?,?,?)";
            connL = this.conn;
            ps = connL.prepareStatement(SQL); 
            
            ps.setInt(1,pessoa.getCod_vendedo());
            ps.setInt(2,pessoa.getCod_casas());
            ps.setString(3,pessoa.getNomeComprador());
            ps.setInt(4,pessoa.getValor());
            ps.executeUpdate();

        }catch(SQLException sqle){
            System.out.println("Erro ao inserir uma nova Venda" + sqle);
        }
        finally{
           ConexaoAulaDAO.close(connL,ps);
        }
    }
    
    
    
    public void Atualizar(Vendas pessoa)throws ErpDAOException  {
        PreparedStatement ps = null;
        Connection connL = null;
        if (pessoa == null){
             throw new ErpDAOException("o objeto não pode ser nulo");
        }

        try{
            String SQL = "UPDATE vendas set nomeComprador=?, valor=? WHERE cod_vendedo=?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL); 
            ps.setString(1, pessoa.getNomeComprador());
            ps.setInt(2, pessoa.getValor());
            ps.setInt(3, pessoa.getCod_vendedo());
            ps.executeUpdate();

        }catch(SQLException sqle){
            System.out.println("Erro ao editar as vendas " + sqle);
        }
        finally{
           ConexaoAulaDAO.close(connL,ps);
        }
    }
    
    
     public void Excluir(Vendas pessoa)throws ErpDAOException{
        PreparedStatement ps = null;
        Connection connL = null;
        if (pessoa == null){
             throw new ErpDAOException("o objeto não pode ser nulo");
        }

        try{
            String SQL = "DELETE FROM vendas WHERE cod_vendedo=?";
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            ps.setInt(1, pessoa.getCod_vendedo());
            ps.executeUpdate();
        }catch(SQLException sqle){
          System.out.println("Erro ao excluir a venda " + sqle);
        }
        finally{
          ConexaoAulaDAO.close(connL,ps);
        }
    }

    

}
