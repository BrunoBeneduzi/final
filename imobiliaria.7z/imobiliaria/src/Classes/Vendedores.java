/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author bbernard
 */
public class Vendedores {
    private int cod_vendedor;
    private String nome;

    
    public Vendedores(){
    }
    
    public Vendedores(int cod_vendedor, String nome){
        this.cod_vendedor = cod_vendedor;
        this.nome = nome;
    }
   
    public int getCod_vendedor() {
        return cod_vendedor;
    }

    
    public void setCod_vendedor(int cod_vendedor) {
        this.cod_vendedor = cod_vendedor;
    }

    
    public String getNome() {
        return nome;
    }

    
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
}
