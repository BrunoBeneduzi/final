/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author bbernard
 */
public class Casa {
    private int cod_casa;
    private String bairro, rua, numero;

   
    public Casa(){}
    
    public Casa(int cod_casa, String numero, String bairro, String rua){
        this.bairro = bairro;
        this.cod_casa = cod_casa;
        this.numero = numero;
        this.rua = rua;
    }
    
    
    public int getCod_casa() {
        return cod_casa;
    }

    
    public void setCod_casa(int cod_casa) {
        this.cod_casa = cod_casa;
    }

    
    public String getNumero() {
        return numero;
    }

   
    public void setNumero(String numero) {
        this.numero = numero;
    }

   
    public String getBairro() {
        return bairro;
    }

    
    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

   
    public String getRua() {
        return rua;
    }

   
    public void setRua(String rua) {
        this.rua = rua;
    }
    
 
}