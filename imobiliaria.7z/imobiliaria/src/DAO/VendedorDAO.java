/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Classes.Vendedores;
import Conexao.ConexaoAulaDAO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author bbernard
 */
public class VendedorDAO {
    
    private Connection conn;
     public VendedorDAO() {
        try{
            this.conn = ConexaoAulaDAO.getConnection();
        }catch(Exception e){
            System.out.println(e.getMessage());;
        }
    }

    public ArrayList Listar() {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList pessoa = new ArrayList();

        try {
            String SQL = "SELECT * FROM vendedor ORDER BY nome";
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                int cod_vendedor = rs.getInt("cod_vendedor");
                String nome = rs.getString("nome");
                

                pessoa.add(new Vendedores(cod_vendedor, nome));

            }

        } catch (SQLException sqle) {
            System.out.println(sqle.getMessage());
        } finally {
            ConexaoAulaDAO.close(connL, ps);
        }

        return pessoa;
    }
    
    public void Inserir(Vendedores pessoa) throws ErpDAOException {         
        PreparedStatement ps = null;
        Connection connL = null;        
        if (pessoa == null){
             throw new ErpDAOException("o objeto não pode ser nulo");
        }
        try{
            String SQL = "INSERT INTO vendedor (nome) " +
                    "values (?)";
            connL = this.conn;
            ps = connL.prepareStatement(SQL); 
            
            ps.setString(1,pessoa.getNome());
            
            ps.executeUpdate();

        }catch(SQLException sqle){
            System.out.println("Erro ao inserir um novo medico" + sqle);
        }
        finally{
           ConexaoAulaDAO.close(connL,ps);
        }
    }
    
    public Vendedores Procurar(int codigo) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        Vendedores pessoa = new Vendedores();
        pessoa = null;

        try{
            String SQL = "SELECT * FROM vendedor WHERE cod_vendedor = ?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            ps.setInt(1, codigo);
            rs = ps.executeQuery();
           
            
            while( rs.next()){
              int cod_vendedor = rs.getInt("cod_vendedor");
              String nome = rs.getString("nome");
            
             
              
              pessoa = new Vendedores(cod_vendedor, nome); 
              
            }
            
            
            
        }catch(SQLException sqle){
            System.out.println("Erro ao procurar medico " + sqle);
        }
        finally{
          // ConexaoAulaDAO.close(connL,ps);
        }
        return pessoa;
    }   
    
    public void Excluir(Vendedores pessoa)throws ErpDAOException{
        PreparedStatement ps = null;
        Connection connL = null;
        if (pessoa == null){
             throw new ErpDAOException("o objeto não pode ser nulo");
        }

        try{
            String SQL = "DELETE FROM vendedor WHERE cod_vendedor=?";
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            ps.setInt(1, pessoa.getCod_vendedor());
            ps.executeUpdate();
        }catch(SQLException sqle){
          System.out.println("Erro ao excluir Medico " + sqle);
        }
        finally{
          ConexaoAulaDAO.close(connL,ps);
        }
    }
          
    public void Atualizar(Vendedores pessoa)throws ErpDAOException  {
        PreparedStatement ps = null;
        Connection connL = null;
        if (pessoa == null){
             throw new ErpDAOException("o objeto não pode ser nulo");
        }

        try{
            String SQL = "UPDATE vendedor set nome=? WHERE cod_vendedor=?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL); 
            ps.setString(1, pessoa.getNome());
            ps.setInt(2, pessoa.getCod_vendedor());
            ps.executeUpdate();

        }catch(SQLException sqle){
            System.out.println("Erro ao editar vendedor " + sqle);
        }
        finally{
           ConexaoAulaDAO.close(connL,ps);
        }
    }
}
