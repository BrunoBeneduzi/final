/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Classes.Casa;
import Conexao.ConexaoAulaDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author bbernard
 */
public class CasasDAO {
  private Connection conn;
     public CasasDAO() {
         
        try{
            this.conn = ConexaoAulaDAO.getConnection();
        }catch(Exception e){
            System.out.println(e.getMessage());;
        }
    }

 
    public ArrayList Listar() {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList pessoa = new ArrayList();

        try {
            String SQL = "SELECT * FROM casas ORDER BY bairro";
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                int cod_casa = rs.getInt("cod_casa");
                String bairro = rs.getString("bairro");
                String rua = rs.getString("rua");
                String numero = rs.getString("numero");
                
                pessoa.add(new Casa(cod_casa, numero, bairro, rua));

            }

        } catch (SQLException sqle) {
            System.out.println(sqle.getMessage());
        } finally {
            ConexaoAulaDAO.close(connL, ps);
        }

        return pessoa;
    }
    
    public void Inserir(Casa pessoa) throws ErpDAOException {         
        PreparedStatement ps = null;
        Connection connL = null;        
        if (pessoa == null){
             throw new ErpDAOException("o objeto não pode ser nulo");
        }
        try{
            String SQL = "INSERT INTO casas (bairro, rua, numero) values (?,?,?)";
            connL = this.conn;
            ps = connL.prepareStatement(SQL); 
            
            ps.setString(1,pessoa.getBairro());
            ps.setString(2,pessoa.getRua());
            ps.setString(3,pessoa.getNumero());
            
            ps.executeUpdate();

        }catch(SQLException sqle){
            System.out.println("Erro ao inserir uma nova casa" + sqle);
        }
        finally{
           ConexaoAulaDAO.close(connL,ps);
        }
    }
    
    public Casa Procurar(int codigo) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        Casa pessoa = new Casa();
        pessoa = null;

        try{
            String SQL = "SELECT * FROM casas WHERE cod_casa = ?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            ps.setInt(1, codigo);
            rs = ps.executeQuery();
           
            
            while( rs.next()){
              int cod_casa = rs.getInt("cod_casa");
              String bairro = rs.getString("bairro");
              String rua = rs.getString("rua");
              String numero = rs.getString("numero");
              
              pessoa = new Casa(cod_casa, numero, bairro, rua); 
              
            }
            
            
            
        }catch(SQLException sqle){
            System.out.println("Erro ao procurar a Casa " + sqle);
        }
        finally{
          // ConexaoAulaDAO.close(connL,ps);
        }
        return pessoa;
    }   
    
    public void Excluir(Casa pessoa)throws ErpDAOException{
        PreparedStatement ps = null;
        Connection connL = null;
        if (pessoa == null){
             throw new ErpDAOException("o objeto não pode ser nulo");
        }

        try{
            String SQL = "DELETE FROM casas WHERE cod_casa=?";
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            ps.setInt(1, pessoa.getCod_casa());
            ps.executeUpdate();
        }catch(SQLException sqle){
          System.out.println("Erro ao excluir a casa " + sqle);
        }
        finally{
          ConexaoAulaDAO.close(connL,ps);
        }
    }
          
    public void Atualizar(Casa pessoa)throws ErpDAOException  {
        PreparedStatement ps = null;
        Connection connL = null;
        if (pessoa == null){
             throw new ErpDAOException("o objeto não pode ser nulo");
        }

        try{
            String SQL = "UPDATE casas set bairro=?, rua=?, numero=? WHERE cod_casa=?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL); 
            ps.setString(1, pessoa.getBairro());
            ps.setString(2, pessoa.getRua());
            ps.setString(3, pessoa.getNumero());
            ps.setInt(4, pessoa.getCod_casa());
            ps.executeUpdate();

        }catch(SQLException sqle){
            System.out.println("Erro ao editar a casa " + sqle);
        }
        finally{
           ConexaoAulaDAO.close(connL,ps);
        }
    }
}
